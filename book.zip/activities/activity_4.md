# Activity 4 - Extension exercise

## 💾 Pointing at your real database

## 💿 Exercise 4.1 - Database connection

The current deployment is using the dev spring profile that points at the in memory database.

As an extension see if you can follow through the instructions again BUT this time try to deploy 
your application so that it points to your real database. 

🙌 Top Tip: Have a look at the application.properties files - are there things you could change there?

🙌 Top Tip: Don't forget to terminate your application once you've finished.




