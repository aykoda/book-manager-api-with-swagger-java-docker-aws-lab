package com.techreturners.bookmanager.model;

public enum Genre {
    Thriller,
    Romance,
    Fantasy,
    Fiction,
    Education,
}
